/* 
*JavaScript Document
*Name: Aaron Posey
*NetId: acposey
*For: Csc337 web programming class
*Instructor: Benjamin Dickens
*PA8 (Chatty!!)
*
*This JS file creates a nodeJS server using the express module.  It stands as a static server and has an API for dynamically posting text in the 
*chatty conversation app.  The server takes POST requests and adds them to a database that stores the conversation.  It also queries the data base 
*to get all the current messages and sends them back to the client to print an up to date conversation.  
*/



//Globals
const express = require('express')
const mongoose = require('mongoose');

const hostname = '159.89.87.73';
const port = 80;

const app = express()

const db = mongoose.connection;
const mongoDBURL = 'mongodb://127.0.0.1/chatty';//???



//Schema
var Schema = mongoose.Schema;

var MessagePostSchema = new Schema({
	name: String,
	message: String,
	timeStamp: Number
})

var NewMessage = mongoose.model('NewMessage', MessagePostSchema); 



//setup static server
app.use(express.static('public_html'))

//setup default mongoose connection
mongoose.connect(mongoDBURL, {useNewUrlParser: true});
db.on('eeror', console.error.bind(console, 'MongoDB connection error;'));





//code for GET request from client to update conversation
app.get('/chats', (req, res) =>{
	var r = mongoose.model('NewMessage', MessagePostSchema);
	r.find({}).exec( function (error, results){
		let result = '';
		for(i in results){
			result += '<b>' + results[i].name + ':  ' + '</b>' + results[i].message + '<br></br>'  
		}
		res.send(result);
	});
});





//code for POST request from client to add a message to the DB
app.post('/chats/post/:alias/:message', (req, res) => {
	
	var alias = req.params.alias;
	var text = req.params.message;
	var timeReceived = Date.now();
	var message = new NewMessage ({name: alias, message: text, timeStamp: timeReceived})
	
	message.save( function (err) {if(err) console.log('an error occurred');});
		res.send('ok');
});




/************************************************************************************************************************************ 
*This section starts the server and listens for requests from user.  
*************************************************************************************************************************************/


app.listen(port, () => 
  console.log(`App listening at http://${hostname}:${port}`))
