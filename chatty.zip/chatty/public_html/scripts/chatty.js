// JavaScript Document
/* 
*JavaScript Document
*Name: Aaron Posey
*NetId: acposey
*For: Csc337 web programming class
*Instructor: Benjamin Dickens
*PA8 (Chatty!!)
*
*This JS file allows the user to click a button and it will POST a text message to the serverside database using an Ajax object for the Post request.  
*Upon completion, the text will be stored in the database as an object with the users name, message, and timestamp.  Every Second the server will be pinged and a 
*GET request will be sent. The database will be queried for the all the content of the current conversation up to date and it will be printed in the conversaion 
*window
*/



//This starts an interval time that runs updatConversation() to ping the server every second for updated messages
pingServer = setInterval(function(){ updateConversation(); }, 1000);


/*  Purpose: This function creates an ajax request and grabs the values from the name and message text fields and creates a custom url
*   		 for the POST request and then sends it to the server which in turn stores it into the datase.  
*   Returns: Nothing
*   Side effects: changes the html code on the text field to clear the text and has server update database
*/
function postMessage(){
	
	//create new ajax request
	var httpRequest = new XMLHttpRequest();
	if (!httpRequest){ return false;}
	
	//do this is the ready state changes to done and all worked ok
	httpRequest.onreadystatechange = ()=>{
		if(httpRequest.readyState === XMLHttpRequest.DONE){
			if(httpRequest.status === 200){
				
				//TODO stuff
			}
			else {alert('ERROR');}
		}
	}
	
	//grab box values
	 let alias = document.getElementById('aliasText').value;
	 let message = document.getElementById('textToSend').value;
	 
		alias = encodeURIComponent(alias);
		message = encodeURIComponent(message);
	
	//build custom url for ajax request  
	let url = 'http://159.89.87.73/chats/post/' + alias + '/' + message;
	console.log(url);
	
	//open request and send it to the server
	 httpRequest.open('POST', url);
  	 httpRequest.send();
	
	//need to clear boxes after post
	document.getElementById('textToSend').value = '';

}


/*  Purpose: This function creates an ajax request that asks the server to query the chatty DB and return the updated messages that have been stored and it updates the 
*   		 conversation window div in the html.
*   Returns: Nothing
*   Side effects: changes the html code on the conversation window div
*/

function updateConversation(){
	
	//create new ajax request
	var httpRequest = new XMLHttpRequest();
	if (!httpRequest){ return false;}
	
	//do this is the ready state changes to done and all worked ok
	httpRequest.onreadystatechange = ()=>{
		if(httpRequest.readyState === XMLHttpRequest.DONE){
			if(httpRequest.status === 200){
				//get chatWindow div element
				var chatWindow = document.getElementById('conversationWindow');
				
				//updatedConversation needs to be set to response text from ajax request.
				let updatedConversation = httpRequest.responseText;
				
				//inject new html into chatWindow div element to update conversation.
				chatWindow.innerHTML = updatedConversation;
			}
			else {alert('ERROR');}
		}
	}
	
	
	//build custom url for ajax request
	let url = 'http://159.89.87.73/chats/';
	console.log(url);
	//open request and send it to the server
	 httpRequest.open('GET', url);
  	 httpRequest.send();
	
	
}


