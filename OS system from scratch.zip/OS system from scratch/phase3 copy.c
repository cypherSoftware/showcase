#include <stdlib.h>                   
#include <strings.h>                  
#include <stdio.h>                     
#include <string.h> 
#include <usyscall.h>
#include <usloss.h>
#include <phase1.h>
#include <phase2.h>
#include <phase3.h>
#include "p3sysCalls.h"



/* ------------------------- Prototypes ----------------------------------- */
static void spawn(sysargs *);
void        wait1(sysargs *);
static void terminate(sysargs *);
void        spawn_launch(void);
static void getTimeofDay(sysargs *);
static void cpuTime(sysargs *);
static void getPID(sysargs *);
int         spawn_real(char *, int (*func)(char *), char *, int, int); 
static void terminate_real(int);
static void add_to_child_list (int, int);
static void remove_from_u_proc_table(int);
static void print_child_list(int);
static void zap_all_children(int);
int         start2(char *); 
int         wait_real(int *status);
static void nullsys3(sysargs *);
static void mutex_using();
static void mutex_done();
extern int  start3 (char *);





/* -------------------------- Globals ------------------------------------- */

int debugflag3 = 0;     //Set to one for debug mode


/* Dummy proc used for initialization of p3_proc_table */                   
u_proc dummy_proc = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ITEM_NOT_IN_USE, NULL, NULL, NULL, NULL, NULL, NULL};

/* Create phase 3  Proc table for keeping track of user procs */
u_proc p3_proc_table[MAXPROC]; 

/* Create global int for mutex_Mbox id  for all the systemcall functions to create mutual exlusion on p3_proc_table changes */
int mutex_mbox;

/* Variable to denote whether a process is in the mutual exclusion zone */
int using_mutex_mbox = 1;







/*----------------------------Functions------------------------------------*/



/* ------------------------------------------------------------------------
   Name - start2
   Purpose - Entry point to Phase 3 system call handling.  Kernal methods, 
             PCB, mailboxes and interrupt handlers already initalized.
   Parameters - One, default arg passed by fork1, not used here.
   Returns -    Returns Zero for successfull quit
   Side Effects - none
   ----------------------------------------------------------------------- */


int start2(char *arg)
{
    int		pid;
    int		status;

    //Create global mutex_Mbox for all the systemcall functions to create mutual exlusion on p3_proc_table changes
    mutex_mbox = MboxCreate(1,sizeof(int));


    /* Initialize the phase2 proc table */
   for (int i = 0; i < MAXPROC; i++){

      p3_proc_table[i] = dummy_proc;


      //Create mailboxes for user process syncronization
            //ZeroSlot start_mbox for each proc to syncronize parent/child during spawn ()
             p3_proc_table[i].start_mbox = MboxCreate(0,MAX_MESSAGE);

             //ZeroSlot private_mbox for message passing
             p3_proc_table[i].private_mbox = MboxCreate(0, MAX_MESSAGE);
   }
    

    //initialize every system call handler as nullsys3;  
    for (int j= 0; j < MAXSYSCALLS; j++){
    
        sys_vec[j] = nullsys3;
    }


    //Initialize sys_vec [] with appropriate methods for each system call
        sys_vec[SYS_SPAWN] = spawn;
        sys_vec[SYS_WAIT] = wait1;
        sys_vec[SYS_TERMINATE] = terminate;
        sys_vec[SYS_GETTIMEOFDAY] = getTimeofDay;
        sys_vec[SYS_CPUTIME] = cpuTime;
        sys_vec[SYS_GETPID] = getPID;


    
    pid = spawn_real("start3", start3, NULL, 4*USLOSS_MIN_STACK, 3);
    pid = wait_real(&status);    //after start3 is successfully spawned, start2 waits for it to finish before shutting down
                    
    quit(0);

} /* start2 */






/* -------------------------------------------------------------------------------
   Name -     spawn
   Purpose -  Wrapper function to unpack the SysArgs pointer sent from Spawn() 
              called by user and to so sanity checks on incoming arguments before 
              sending args to spawn_real function that actually calls fork1()
   Parameters - Args_ptr passed in from System call that has *func ptr, 
                char* function args, int stack size int priority and char name.
   Returns -    Nothing
   Side Effects -  none
   ------------------------------------------------------------------------------- */

static void spawn(sysargs *args_ptr)
{
   int (*func)(char *);
   char *arg;
   int stack_size;
   int kid_pid;
   char *name;
   int priority;
  

    //process was zapped terminate the process 
   if (is_zapped() ) { 

        terminate_real(-1); //process was zapped and forced to terminate
   }

   func = args_ptr->arg1;
   arg = args_ptr->arg2;
   stack_size = (int) args_ptr->arg3;
   priority = args_ptr->arg4;
   name  = args_ptr->arg5;

    
   
   kid_pid = spawn_real(name, func, arg, stack_size, priority);
    args_ptr->arg1 = (void *) kid_pid;
    args_ptr->arg4 = (void *) 0;

    //process was zapped terminate the process 
   if (is_zapped() ) { 

        terminate_real(-1); //process was zapped and forced to terminate
   }
   
return ; 

}
/* spawn */






/* ------------------------------------------------------------------------------------------------
   Name - spawn_real
   Purpose -  Most of the parent/child syncronization is done here.  fork1 in 
              this process has child run the spawn launch code to block the child
              and give the parent a chance to syncronize before launching child.
   Parameters - char name of process, function ptr, char args for function, 
                int stack size, int priority level
   Returns -    The kidpid of the new process to the parent so the parent can join later if need be.
   Side Effects - Adds to the Phase 3 process table and needs mutual exclusion to avoid race conditions
   -------------------------------------------------------------------------------------------------- */

 int spawn_real(char *name, int (*func)(char *), char *arg, int stack_size, int priority) 
{
    int kidpid;          //child's PID
    int parent_location; //parents location in proc table
    int kid_location;    //kids location in proc table
    int result;          //for documents success/failure of mboxes
  

    //starting to modify critical region use mutex
    //mutex_using();

   parent_location = getpid() % MAXPROC;
   
    //process was zapped terminate the process 
    if (is_zapped() ) {  

    terminate_real(-1); //process was zapped and forced to terminate
   }

        if (DEBUG3 && debugflag3){
            console("%s is entering spawn_real\n",p3_proc_table[parent_location].name);
        }

    // Note: Expecting parent is running this function



                    /* create our child */
        //increment parent's numkids count
    p3_proc_table[parent_location].num_kids ++;
   kidpid = fork1(name, spawn_launch, NULL, stack_size, priority);
   
   if(kidpid == -1){    //child spawning unsuccessful change kid count back to what it was and don't continue
       p3_proc_table[parent_location].num_kids --;
      return kidpid;
   }


            /*****Fill in p3_proc_table entry****/
    
    //add kid info that's known to p3_proc_table
    kid_location = kidpid % MAXPROC;                     //get kids location in p3_proc_table
    p3_proc_table[kid_location].pid = kidpid;            //add pid field
    strcpy(p3_proc_table[kid_location].name, name);      //add name field
    p3_proc_table[kid_location].priority = priority;     //add priority field
    p3_proc_table[kid_location].stacksize = stack_size;  //add stack size field
    p3_proc_table[kid_location].start_func = func;       //add start func ptr field
    p3_proc_table[kid_location].parent_pid = getpid();   //add parent pid field
    p3_proc_table[kid_location].num_kids = 0;            //add num_kids field
        if(arg != NULL){                                 //add function arg field
         strcpy(p3_proc_table[kid_location].start_arg, arg); 
        }                                                 
    
            /***** End of p3_proc_table entry fill for new kid*****/
   

    //add new child to child list
    add_to_child_list(parent_location, kid_location);

    //Synchronize with the child using a mailbox by Sending parent location for child to fill in PCB entry
    result = MboxSend(p3_proc_table[kid_location].start_mbox, &parent_location, sizeof(int));

    //Process zapped terminate the process
    if (is_zapped() ) {  

    terminate_real(-1); //process was zapped and forced to terminate
   }

    if (DEBUG3 && debugflag3){
            console("%s is now exiting spawn_real\n",p3_proc_table[parent_location].name);
        }

    //finished modifying critical region unlock now
    //mutex_done();

   return kidpid; 
}
/* spawn_real */






/* ------------------------------------------------------------------------------------------------------------
   Name - spawn_launch
   Purpose - Launches the code pointed to in spawn_real.  It's purpose is to coordinate 
           - the completion of the phase 3 process table entries needed for the new process,
           - before launching the code.  The process gets blocked until parent catches up and it receives actual 
           - start code location for the child.  Then it's switched into user mode before being ran.
   Parameters - None
   Returns - Nothing
   Side Effects -  Makes changes to the phase 3 process table and needs mutual exclusion to avoid race donditions
   ------------------------------------------------------------------------------------------------------------ */

void spawn_launch()
{
   int result;                   //for mbox syncronization
   int parent_location = 0;      //parent's location indes in p3_proc_table
   int my_location;              //new childs location index in p3_proc_table
   int(*start_function)(char *); //new childs start function ptr
   char *start_arg;              //new child's start function arguments   
  
    //starting to modify critical region use mutex
    //mutex_using();


    // set start_func and start_arg need to be set to values from PCB
   my_location = getpid() % MAXPROC;

    //if zapped terminate the process 
    if (is_zapped() ) { 

      terminate_real(-1); //process was zapped and forced to terminate
    }


   //Note:  Child proc should be running this method

   //Receive parent location from parent from start_mbox, so the rest of it's proc table entry can be filled in  
    result = MboxReceive(p3_proc_table[my_location].start_mbox, &parent_location, sizeof(int));


                /******Add what kid knows to  p3_proc_table entry******/
   p3_proc_table[my_location].status = ITEM_IN_USE;                                 //add status field
   p3_proc_table[my_location].is_zapped = is_zapped();                              //add is zapped field
   p3_proc_table[my_location].parent_proc_ptr = &p3_proc_table[parent_location];    //add parent_proc_ptr location
                /***** End p3Proc_table entry data dump******/


   if ( !is_zapped() ) {
       
     //Then set up user mode
      psr_set(psr_get() & ~PSR_CURRENT_MODE);

    //done modifying critical region unlock
    //mutex_done();


                             //$$$$$$$$$$$$$$$$$$ This starts the forked Function $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
     start_arg = p3_proc_table[my_location].start_arg;
      result = (p3_proc_table[my_location].start_func)(start_arg);     
      Terminate(result);
   }
   else {
      terminate_real(0);    //child ran and returned time to stop spawn_launch()
   }
   printf("spawn_launch(): should not see this message following Terminate!\n");

//done modifyong critical region unlock
//mutex_done();


   return;
 } 
/* spawn_launch */



    
  

/* ------------------------------------------------------------------------
   Name - wait
   Purpose -  Wrapper function to unpack sysargs, do sanity checks and then call wait_real
   Parameters - sysargs pointer 
   Returns -  nothing 
   Side Effects -  none
   ----------------------------------------------------------------------- */
void wait1(sysargs *args_ptr)
{   
    int status;
    

    args_ptr->arg1 = wait_real(&status); //call wait_real to make proc wait upon return assign pid of quitting child to 
    args_ptr->arg2 = status;             //assign status to SA arg struct for Wait()
    args_ptr->arg4 = 0;                  //assign sucess value "0" to SA arg struct for Wait()

return;
}
/* wait */





/* -----------------------------------------------------------------------------------------------
   Name - wait_real
   Purpose -  This is the real wait function.  This calls join in the kernal
              to force a parent to wait for one of its children to terminate.
   Parameters -  Int* status to pass into join for the exit code of the terminated child 
   Returns -    The Pid of the terminated child.
   Side Effects -  Makes changes to the user process table so needs mutual exclusion to 
                   avoid race conditions.
   --------------------------------------------------------------------------------------------- */

int  wait_real(int *status)
{//************DONT FORGET MUTEX STUFF IN EACH SYSCALL************************
    int quitting_child;
    int my_location;

    my_location = getpid() % MAXPROC;

    if (DEBUG3 && debugflag3){
            console("%s is now entering wait_real\n",p3_proc_table[my_location].name);
        }


    //Process zapped terminate the process
    if (is_zapped() ) {  

        terminate_real(-1); //process was zapped and forced to terminate
   }


    //run join.  Check result value of quitting child
    quitting_child = join(status);

    //process had no children no need to wait just return
    if(quitting_child == -2){   
        return -2;

        if (DEBUG3 && debugflag3){
            console("%s is now leaving wait_real\n",p3_proc_table[my_location].name);
        }
    }
    
    //Process zapped terminate the process
    if (quitting_child == -1)   
    {
        terminate_real (-1);
    }


    if (DEBUG3 && debugflag3){
            console("%s is now leaving wait_real\n",p3_proc_table[my_location].name);
        }

    return quitting_child;
}

/* wait_real */




/* -------------------------------------------------------------------------------------------
   Name - terminate
   Purpose -   Wrapper function to unpack sysarg pointer, doing sanity checks and then 
                calling terminate_real().
   Parameters - Sys args * passed in from user system call.   
   Returns -    nothing 
   Side Effects -  none
   ----------------------------------------------------------------------------------------- */

static void terminate(sysargs *args_ptr)
{
int status = (int)args_ptr->arg1;


    terminate_real(status);


    return;
}

/* treminate */





/* -----------------------------------------------------------------------------------------------------
   Name - terminate_real
   Purpose -  The real terminate function.  This function makes sure that all 
               the children of a function are zapped then kills the process calling it.
   Parameters -  int status for how the process is terminated so it can send an exit code to it's parent
   Returns -   Nothing  
   Side Effects -  Makes changes to the user process table and adjusts the list of children each process
                   has as children get terminated
   ----------------------------------------------------------------------------------------------------- */

static void terminate_real(int status)
{
    int my_location = getpid() % MAXPROC;


    if (DEBUG3 && debugflag3){
            console("%s is now entering terminate_real\n",p3_proc_table[my_location].name);
            console("\n\n here is my child list\n\n");
            print_child_list(my_location);
        }

if (p3_proc_table[my_location].num_kids > 0){   //process has kids zapp them

    
    zap_all_children(my_location);  //each child needs to be zapped before process can quit 
}

    // process has no kids okay to quit but first update the p3_proc_table
    remove_from_u_proc_table(my_location);  //remove terminatinng process from p3_proc_table and update children list of parent
    
    if (DEBUG3 && debugflag3){
            console("%s is now quiting\n",p3_proc_table[my_location].name);
            console("here is a list of the current processes running\n");
            dump_processes();
        }

        
    quit(status);   //quitting


    return;
}
/* terminate_real */





/* ------------------------------------------------------------------------
   Name - getTimeofDay
   Purpose - 
   Parameters - 
   Returns - 
   Side Effects -  
   ----------------------------------------------------------------------- */
static void getTimeofDay(sysargs *args_ptr)
{
    args_ptr->arg1 = (void*) sys_clock();

    return;
}
/* getTimeofDay */




/* ------------------------------------------------------------------------
   Name - cpuTime
   Purpose - Retrieves the total cpu time used by the calling process 
   Parameters - none
   Returns -  nothing.  Just fills in the sysargs pointer passed in by libuser.c
   Side Effects -  none
   ----------------------------------------------------------------------- */
static void cpuTime(sysargs *args_ptr)
{
    int cpu_time_used = readtime();
    args_ptr->arg1 = (void*) cpu_time_used;


    return;

}
/* cpuTime */



/* ------------------------------------------------------------------------
   Name - getPID
   Purpose - Retrieve the PID of the process making the system call
   Parameters - none
   Returns -  nothing.  Just fills in the sysargs pointer passed in by libuser.c
   Side Effects -  none
   ----------------------------------------------------------------------- */

static void getPID(sysargs *args_ptr)
//************DONT FORGET MUTEX STUFF IN EACH SYSCALL************************
{

    int pid = getpid();

    args_ptr->arg1 = (void*) pid;

    return;

}
/* getPID */







/* ------------------------------------------------------------------------
   Name - add_to_child_list
   Purpose - add a child to the linked list of children owned by a process
   Parameters - int index loction in p3_proc_table of process adding child
   Returns -    nothing
   Side Effects -  adjusts pointer to p3_prob_table entrires and needs mutual 
                    exclusion to avoid race conditions
   ----------------------------------------------------------------------- */

static void add_to_child_list (int parent_location, int kid_location)
{
    u_proc_ptr walker;          //walker u_proc_ptr to walk through linked list

    
   if(p3_proc_table[parent_location].child_proc_ptr == NULL)    //if parent's child pointer null then parent has no previous children add child here
   {
       p3_proc_table[parent_location].child_proc_ptr = &p3_proc_table[kid_location];    //first kid
   }
   else
   {
       walker = p3_proc_table[parent_location].child_proc_ptr;  //child pointer not null so goto childs next sibling ptr to check for more children

        while(walker->next_sibling_ptr != NULL)     //next sibling ptr not null so there are still more kids keep going
        {
            walker = walker->next_sibling_ptr;      //move walker ptr to next kid
        }
      walker->next_sibling_ptr = &p3_proc_table[kid_location];  //found an empty spot at end of list add child here
      walker->next_sibling_ptr->prev_sibling_ptr =  walker;     //point prev_sibling_ptr of new child back to its previous sibling????????????
   }

   p3_proc_table[kid_location].parent_proc_ptr = &p3_proc_table[parent_location];   //point newly added child's parent pointer back to Mommy or Daddy
   // p3_proc_table[parent_location].num_kids++;          // increment kid count ++


    if (DEBUG3 && debugflag3){

        // print_child_list(parent_location);  //verify child added properly
    }


return;

}
/*add_to_child_list*/






/* ------------------------------------------------------------------------
   Name - zap_all_children
   Purpose - To zap all of a process's children one at a time.  The process will 
            get blocked until all children are terminated sucessfully
   Parameters - int index location of process on p3_proc_table
   Returns -    nothing
   Side Effects -   none
   ----------------------------------------------------------------------- */


 static void zap_all_children(int location)
 {
     if (DEBUG3 && debugflag3){
            console("%s is now entering zap_all_children\n",p3_proc_table[location].name);
            console("here is my child list b4 the zapping.\n\n");
            print_child_list(location);
        }
    //console("The child about to be zapped is pid %d and named %s\n",p3_proc_table[location].child_proc_ptr->pid, p3_proc_table[location].child_proc_ptr->name);
     while (p3_proc_table[location].child_proc_ptr != NULL) // if child_proc_ptr not Null then process still has children.
     {

        // dump_processes();
        
         zap(p3_proc_table[location].child_proc_ptr->pid);  //zap child and wait for it to terminate. The terminate function will update child ptr
       
     }

     //child ptr was null so no more children all have been zapped and terminated.

        if (DEBUG3 && debugflag3){
            console("%s is now exiting zapp_all_children here is my child list after zapping\n",p3_proc_table[location].name);
            print_child_list(location);
        }

     return;
 }
/* zap_all_children*/




/* ------------------------------------------------------------------------
   Name - print_child_list
   Purpose - Print out the list of a process' children for debugging pruposes
   Parameters - int index location of process in p3_proc_table
   Returns -    nothing
   Side Effects -  none
   ----------------------------------------------------------------------- */

static void print_child_list(int location)
{
    u_proc_ptr walker;

    console("\n\n########################################### Print Child List for Process %s **************************************\n",p3_proc_table[location].name);
    if (p3_proc_table[location].child_proc_ptr == NULL)
    {
        console("No children for this process\n");
    }
    else{
        console("Parent: %s ---> kid: %s",p3_proc_table[location].name, p3_proc_table[location].child_proc_ptr->name);

        walker = p3_proc_table[location].child_proc_ptr;

            while(walker->next_sibling_ptr != NULL){
                walker = walker->next_sibling_ptr;
                console("----> kid: %s", walker->name);
            }      
    }
    console("----> NULL\n");
    console("################################################ End of child list ################################################\n\n");
        return;
}
/* print_child_list*/






/* ------------------------------------------------------------------------
   Name - remove_from_u_proc_table
   Purpose -  Removes process' from p3_proc_table when it terminates
   Parameters - int index location of process in p3_proc_table
   Returns -    nothing
   Side Effects -  Removes entry from p3_proc_table
   ----------------------------------------------------------------------- */

static void remove_from_u_proc_table(int my_location)
{
    u_proc_ptr my_parent_proc_ptr;

    //starting to modify critical region use mutex
    //mutex_using();

    
    if(p3_proc_table[my_location].parent_proc_ptr != NULL){
        
       my_parent_proc_ptr = p3_proc_table[my_location].parent_proc_ptr;   //get parent_proc_ptr
    }
    else{
        //I'm start2() and have no parent ptr just return
        return;
    }


        //sever ties with parent
          if(p3_proc_table[my_location].prev_sibling_ptr == NULL && p3_proc_table[my_location].next_sibling_ptr == NULL){  //I'm an only child
        my_parent_proc_ptr->child_proc_ptr = NULL;  //set parent's child_proc_ptr to NULL 
        
         p3_proc_table[my_location] = dummy_proc;
         p3_proc_table[my_location].status = ITEM_NOT_IN_USE;
         my_parent_proc_ptr->num_kids --;   //decrement kid counter
        
        //done modifying critical region unlock
        //mutex_done();

        return;
    }


        //sever ties with siblings if there is a family
     if(p3_proc_table[my_location].prev_sibling_ptr != NULL && p3_proc_table[my_location].next_sibling_ptr == NULL){//I'm the last child. 
        p3_proc_table[my_location].prev_sibling_ptr->next_sibling_ptr = NULL;                                    //set prev_sibling's next sibling to null
        p3_proc_table[my_location].prev_sibling_ptr = NULL;    //set me previous sibling ptr to null

         p3_proc_table[my_location] = dummy_proc;
         p3_proc_table[my_location].status = ITEM_NOT_IN_USE;
         my_parent_proc_ptr->num_kids --;   //decrement kid counter
        
        //done modifying critical region unlock
        //mutex_done();

         return;
    }
    
    if (p3_proc_table[my_location].prev_sibling_ptr != NULL && p3_proc_table[my_location].next_sibling_ptr != NULL) {//I'm a middle child
        p3_proc_table[my_location].prev_sibling_ptr->next_sibling_ptr = p3_proc_table[my_location].next_sibling_ptr; //point prev_sibling to next sibling
        p3_proc_table[my_location].next_sibling_ptr->prev_sibling_ptr = p3_proc_table[my_location].prev_sibling_ptr; //point next sibling to previous sibling
        p3_proc_table[my_location].prev_sibling_ptr = NULL; //set my prev pointer to null
        p3_proc_table[my_location].next_sibling_ptr = NULL;  //set my next sibling ptr to null


         p3_proc_table[my_location] = dummy_proc;
         p3_proc_table[my_location].status = ITEM_NOT_IN_USE;
         my_parent_proc_ptr->num_kids --;   //decrement kid counter
        
        //done modifying critical region unlock
        //mutex_done();

         return;
    }

    if (p3_proc_table[my_location].prev_sibling_ptr == NULL && p3_proc_table[my_location].next_sibling_ptr != NULL){ //I'm the first born point parent's 
        my_parent_proc_ptr->child_proc_ptr = p3_proc_table[my_location].next_sibling_ptr;                           //child_ptr to next sibling
        p3_proc_table[my_location].next_sibling_ptr->prev_sibling_ptr = NULL;     //point next sibling's previous to null
        p3_proc_table[my_location].next_sibling_ptr = NULL;  //point my next sibling ptr to null.

        p3_proc_table[my_location] = dummy_proc;
        p3_proc_table[my_location].status = ITEM_NOT_IN_USE;
         my_parent_proc_ptr->num_kids --;   //decrement kid counter
        
        //done modifying critical region unlock
       // mutex_done();

        return;
    }

}
/* remove_from_u_pro_table*/





/* ------------------------------------------------------------------------
   Name - nullsys3
   Purpose - Runs a syscall function for undefined syscalls.  It terminates 
             the calling process instead of halting the OS
   Parameters - none
   Returns -    nothing
   Side Effects -  none
   ----------------------------------------------------------------------- */

static void nullsys3(sysargs *args_ptr)
{
   printf("nullsys3(): Invalid syscall %d\n", args_ptr->number);
   printf("nullsys3(): process %d terminating\n", getpid());
   terminate_real(1);
} 
/* nullsys3 */




/* ------------------------------------------------------------------------------
   Name - mutex_using
   Purpose - Locks out other procs from critical regions to avoid race conditions 
   Parameters - none
   Returns -    nothing
   Side Effects -  none
   ----------------------------------------------------------------------------- */


static void mutex_using()
{
    int result;
    

    //starting a mutually exlusive procedure need to lock out other processes
    //If not in use slot should be empty.  Make send call if other procs try to acess then they will get blocked

    result = MboxSend(mutex_mbox, &using_mutex_mbox, sizeof(int));
    return;
}
/* mutex_using */



/* ------------------------------------------------------------------------------
   Name - mutex_done
   Purpose - unLocks critical regions so other procs can enter 
   Parameters - none
   Returns -    nothing
   Side Effects -  none
   ----------------------------------------------------------------------------- */


static void mutex_done()
{
    int message_passed;
    int result;

    //Done with mutually exlusive procedure need to unlock critical region
    // If other procs tried to go into critical region and got locked out this will release them.
    result = MboxReceive(mutex_mbox, &message_passed, sizeof(int));

    return;
}
/* mutex_done */



//quick grab debug code

/*

if (DEBUG3 && debugflag3){

}

*/
