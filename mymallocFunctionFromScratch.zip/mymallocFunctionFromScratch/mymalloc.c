#include <stdio.h>
#include "mymalloc.h"
#include <unistd.h>

struct Node {       //struct for linked list Node

    int chunk_o_memory_size;
    int is_free;
    struct Node *previous;
    struct Node *next;



};

struct Node *head = NULL;       //make head of list and set to NULL
struct Node *tail = NULL;       //make tail of list and set to NULL





//Function Declarations
struct Node *find_free_block(int size);
void *increase_heap(int size);
void split_block(struct Node *big_block, int size);
void coalesce_consec_free_blocks();
void mergeBlocks(struct Node *freeBlock1, struct Node *freeBlock2);









        //************************************** my_firstfit_malloc and helper functions section *****************************************



void *my_firstfit_malloc(int size){

      struct Node *free_block;          
      void *new_allocation_ptr;

     free_block = find_free_block(size);       //look for free block of memory in the heap by checking linked list

      if (free_block == -1 ){       //if find_free_block fails then increase heap
        free_block = increase_heap(size);       //call to increase heap will call append node and update linked list
        if (free_block == -1){      //if new_allocation_ptr is still -1 at this point then there was no more mem for heap to grow
            return -1;
        }
        new_allocation_ptr = free_block;    // heap was increased and a free block was created now assign new_allocation_ptr to free block and return to caller
        return new_allocation_ptr;
      }


      new_allocation_ptr = free_block;
        //a free block was found from the linked list now fill in data


        //************************%%%%%%%%%% last thing to implement %%%%%%%%%%******************$$$$$$$
      if (free_block->chunk_o_memory_size > (size + sizeof(struct Node) +  1)){      //if block returned is larger than allocation request + node + 1 byte
          split_block(free_block, size);                                                   //then split block.
      }
    else{
          free_block->is_free = 0;
          free_block->chunk_o_memory_size = size;
   }

    return new_allocation_ptr + sizeof(struct Node);
}










void split_block(struct Node *big_block, int size) {

    struct Node *spare_change = ((void*)big_block) + size;     //set new spare change node to where it will be following the big block allocation amount


    spare_change->previous = big_block;
    spare_change->next = big_block->next;
    big_block->next->previous = spare_change;
    big_block->next = spare_change;
    spare_change->chunk_o_memory_size = big_block->chunk_o_memory_size - size - sizeof(struct Node);
    spare_change->is_free = 1;
    big_block->is_free = 0;
    big_block->chunk_o_memory_size = size;



}










void append_node(struct Node *new_node_ptr, int mem_size ){

    struct Node *newNode;               //create new node and fill in data

    newNode = new_node_ptr;

    if(head == NULL){


        head = new_node_ptr;
        tail = head;
        head->is_free = 0;
        head->chunk_o_memory_size = mem_size;
        head->previous = NULL;
        head->next = NULL;
    }
    else {

        tail->next = newNode;              //tail is last node so set last node's next to new node ptr
        newNode->is_free = 0;                   //set is_free to 0 (false)
        newNode->chunk_o_memory_size = mem_size;   //set memorysize
        newNode->previous = tail;                   //set previous ptr to previous last node
        newNode->next = NULL;                       //set last node's next to NULL
        tail = newNode;                              //move tail ptr to end of linked list
    }
}












void *increase_heap(int size) {

    void *old_brk_ptr;
    void *new_brk_ptr;
    void *allocated_mem;

    old_brk_ptr = sbrk(size + sizeof(struct Node));     //increment heap brk pointer by amount of variable size + sizeof struct Node for mem tracking

    new_brk_ptr = sbrk(0); //get value of new heap ptr



    if (old_brk_ptr == -1){     //return null if sbrk fails
        return -1;
    }

    append_node(old_brk_ptr , size );
    //printf("\n size : %d  old brk ptr : %p new brk ptr : %p \n",size,old_brk_ptr,new_brk_ptr);

    allocated_mem = old_brk_ptr + sizeof(struct Node);    //set new
    return allocated_mem;

}












struct Node *find_free_block(int size) {       //this function  traverses the LL and look for first block that can take memory size requested

    struct Node *temp;

    temp = head;        //set temp to head so it can used to traverse list and not risk losing head reference

    while (temp != NULL){                           //while not an empty node keep walking thru list
        if(temp->is_free != 0 && temp->chunk_o_memory_size >= size){        //check for free memory and that there is enough to handle request
            return temp;                            //if successful return pointer to that block
        } else{
            temp = temp->next;                          //go to next node in list
        }
    }

    return -1;                  //if no node is found then return -1 to inform caller search was unsuccessfull
}






//***************************** my_free and helper functions section ****************************
void my_free(void *ptr){

    struct Node *temp;

    temp = head;        //set temp to head so it can used to traverse list and not risk losing head reference

    while (temp != NULL){                           //while not an empty node keep walking thru list
        if(temp == (ptr - sizeof(struct Node)) ){   //check for free memory and that there is enough to handle request
            temp->is_free = 1;                      //if successful return pointer to that block
            //printf("\nmemory freed successfully\n");
            coalesce_consec_free_blocks();
            return;
        } else{
            temp = temp->next;                          //go to next node in list
        }
    }
    //printf("\nmemory not freed successfully\n");
    return;                  //if no node is found then return -1 to inform caller search was unsuccessfull
}












void coalesce_consec_free_blocks() {

    struct Node *temp;
    void *current_break_ptr;
    void *old_break_ptr;
    int dec_amount;

    temp = head;        //set temp to head so it can used to traverse list and not risk losing head reference

    while (temp != NULL){                           //while not an empty node keep walking thru list
        if(temp->is_free != 0){                      //check for free memory block
             if(temp->next != NULL && temp->next->is_free != 0 ){    //free block found now check if next block exists and is free
                 mergeBlocks(temp, temp->next);         //found two free consecutive blocks merge them
                 //return;
             }
             else{
                 temp = temp->next;             //free block did not have a free block next to it so continue traversing list
             }
        } else{
            temp = temp->next;                          //did not find a free block go to next node in list
        }
    }

    //Check if tail is free if so brk pointer needs to be decremented and extra heap released back to the OS
    if(tail->is_free != 0){
        if(tail == head && head->is_free != 0){     //if one node left and its free wipe it out and set tail and head to null then move break pointer

            dec_amount = (head->chunk_o_memory_size + sizeof(struct Node)); //add head's mem chunk to struct size
            dec_amount = dec_amount* (-1);                                   // and negate
            head = NULL;
            tail = NULL;

            old_break_ptr = sbrk(dec_amount);   //get rid of last list and return heap
        }
        else {
            dec_amount = tail->chunk_o_memory_size + sizeof(struct Node);   //add tail's mem chunk to struct size
            dec_amount = dec_amount * (-1);     //negate
            tail = tail->previous;          //move tail to previous node and drop its next pointer so it wont be accidently accessed outside the heap
            if (tail != NULL) {              //if tail not null then next can be accessed and set to Null
                tail->next = NULL;          //set tail next to null
            }

            old_break_ptr = sbrk(dec_amount);       //release extra heap to OS
        }

    }
}








void mergeBlocks(struct Node *freeBlock1, struct Node *freeBlock2) {
    if(freeBlock2->next == NULL){
        tail = freeBlock1;
        freeBlock1->chunk_o_memory_size = (freeBlock1->chunk_o_memory_size +(freeBlock2->chunk_o_memory_size + sizeof(struct Node)));
        freeBlock1->next = freeBlock2->next;
    }
    else {
        freeBlock1->chunk_o_memory_size = (freeBlock1->chunk_o_memory_size +(freeBlock2->chunk_o_memory_size + sizeof(struct Node)));
        freeBlock1->next = freeBlock2->next;
        freeBlock2->next->previous = freeBlock1;
    }



}












//*********************************** print list function for debugging **********************************

void print_list(struct Node *n){
    int counter = 0;


    printf("Your current linked list is: ");
    while (n != NULL) {                     //not a NULL pointer so print contents of node
        printf("| size: %d is_free: %d this address: %p next: 0x%x prev: %p| -->",n->chunk_o_memory_size, n->is_free, n, n->next, n->previous);
        n = n->next;                    //walk through list
        counter ++;                     //count how many nodes visited to know what to divide by to get avg

    }

    printf("NULL");
    printf("\n\n Total number of nodes: %d \n", counter );
}








      /*      //********************************* Main section ********************************** for debugging
int main() {

    void *test1;
    void *test2;
    void *test3;
    void *test4;
    void *test5;

    printf("Hello, World!\n");

    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    print_list(head);

    //my_free(test1);
    my_free(test2);
    print_list(head);
    test5 = my_firstfit_malloc(30);
    //test2 = my_firstfit_malloc(100);
    //print_list(head);
    //my_free(test3);

    //print_list(head);
    //my_free(test4);
    //increase_heap(75);
    //increase_heap(80);
    //increase_heap(100);
    //increase_heap(125);

    print_list(head);       //print list


    return 0;
}*/