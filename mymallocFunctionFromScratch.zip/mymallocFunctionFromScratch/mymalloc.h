//
// Created by Aaron Posey on 11/6/19.
//


#include <stdio.h>
#ifndef MY_MALLOC_MYMALLOC_H
#define MY_MALLOC_MYMALLOC_H

#endif //MY_MALLOC_MYMALLOC_H



//function prototypes
void *my_firstfit_malloc(int size);

void my_free(void *ptr);


