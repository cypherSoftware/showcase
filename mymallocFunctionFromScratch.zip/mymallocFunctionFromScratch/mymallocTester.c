//
// Created by Aaron Posey on 11/12/19.
//
#include <stdio.h>
#include "mymalloc.h"
#include <unistd.h>





int main() {

    void *test1;
    void *test2;
    void *test3;
    void *test4;
    void *test5;


    //uncomment the test you'd like to run.

   /*
    //*****Test1******* test icncrease heap and free

    test1 = my_firstfit_malloc(25);
    my_free(test1);
   */

   /*
    //*****Test2******test linked list and free from middle
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    print_list(head);

    my_free(test2);
    print_list(head);
    */

   /*
    //******Test3************ test first fit
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    my_free(test2);
    print_list(head);

    test5 = my_firstfit_malloc(30);
*/


   /*
    //******Test4************ dropping tail
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);


    my_free(test4);
    print_list(head);       //print list
*/


   /*
    //******Test5************ dropping head
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    my_free(test1);
    print_list(head);       //print list
*/



   /*
    //******Test6************ test coalesce
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    my_free(test1);
    my_free(test2);
    print_list(head);       //print list
*/

  /*
    //******Test7************ test complete wipeout
    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    my_free(test1);
    my_free(test2);
    my_free(test3);
    my_free(test4);

    print_list(head);       //print list
*/


  /*
    //******Test8************ loads of crapola

    test1 = my_firstfit_malloc(25);
    test2 = my_firstfit_malloc(100);
    test3 = my_firstfit_malloc(150);
    test4 = my_firstfit_malloc(200);

    my_free(test1);
    my_free(test2);
    test5 = my_firstfit_malloc(300);
    my_free(test4);
    my_free(test1);
    test1 = my_firstfit_malloc(80);

    print_list(head);       //print list
    */


    return 0;
}