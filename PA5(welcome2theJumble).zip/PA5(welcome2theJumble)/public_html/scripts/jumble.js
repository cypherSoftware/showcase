Release





//Globals
shift = 1; //number to shift by for Caesar Cipher
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; //for Caesar Cipher
randomLetters = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y"]; //for square cipher





//Functions


/*Purpose: This function updates the value of the slider as the user slides the slider
* Parameters: accepts the current value of the slider (string).  
* Returns: Nothing
* Side effects: Changes the global variable shift
*/
function showSlidervalue(slideVal)
{
	document.getElementById("sliderValOutput").innerText = slideVal;
	shift = parseInt(slideVal);
	
}


/*Purpose: This function updates the encrypted text in the Caesar cipher box when user adjust text input bar
* Parameters: none  
* Returns: Nothing
* Side effects: none
*/
function updateCaesar(){
	
	//get caesarCipher div
  let result = document.getElementById('caesarCipher');
	//get text from input box
  let text = document.getElementById('inputText').value;
	//new text string to build
  let newText = '';
	
  text = text.toUpperCase();
	
	
	//loop through the input text and build an encrypted string each time
	for (i = 0; i < text.length; i++){
		newText = newText += encryptedLetter(text[i]);
		
	}
	//output new encrypted text
	result.innerText = newText;
  	
}



/*Purpose: This function encrypts a letter passed in using the caesar cipher and current shift value.
* Parameters: accepts a letter to be encrypted(string).  
* Returns: encrypted letter (string)
* Side effects: none
*/
function encryptedLetter(unencryptedLetter){
	
	// get letter ascii num
	let spotNum =  unencryptedLetter.charCodeAt(0);
	//check if letter is regular letter and not number of grammer symbol
	if(spotNum > 64 &&  spotNum < 91){
		
		//add shift then subtract 65 to get place in alphabet ascii starts with A at 65 so -65 makes it index 0 on alphabet 
		spotNum = (spotNum + shift) - 65;
		//if spotNum over 26 need to mod to go back to begining of aphabet string
		if ( spotNum > 25 ){
			spotNum = spotNum % 26;
		}
		return alphabet[spotNum];

		}
	return unencryptedLetter;
	
}



/*Purpose: This function updates the table with the key for the square cipher
* Parameters: none  
* Returns: Nothing
* Side effects: calls randomize letters which changes global variable randomLetters
*/
function updateSquare(){
	
	randomizeLetters();
	//get a list of all the squares in the table
	let results = document.getElementsByClassName('letterSquare');
	
	//loops through all squares in table and updates their text to a new letter based upon the randomLetter global array of letters
	for (i = 0; i < results.length; i++){

		results[i].innerText = randomLetters[i];
	}
	
}



/*Purpose: This function randomizes the randomLetters array using the Fisher-Yates shuffle algorithm.  
*          (note to grader:  If there is an onboard shuffle I in JS, I do not know it.)
* Parameters: none
* Returns: Nothing
* Side effects: Changes the global variable randomLetters
*/
function randomizeLetters(){
  var swaps = 24;
  var temp = "";
  var idx = 0;
	//get value at 25th element swap with random element then grab next element down and repeat 25 times
	while(swaps > 0){
  		idx = Math.floor((Math.random() * swaps));
		temp = randomLetters[swaps]; //hold old value
		randomLetters[swaps] = randomLetters[idx]; //overwrite with value from random spot
		randomLetters[idx] = temp; //place overwrite random index with temp value
		swaps--;  //decrement swap count
		
  	}
  
	
}




/*Purpose: This function updates the text in the square cipher encrypted text section.
* Parameters: none 
* Returns: Nothing
* Side effects: none
*/
function updateSquareText(){
	
	//get squareCipher div
  let result = document.getElementById('squareCipher');
	//get text from input box
  let text = document.getElementById('inputText').value;
	//new text string to build
  let newText = '';
	
  text = text.toUpperCase();
	
	
	//loop through the input text and build an encrypted string each time
	for (i = 0; i < text.length; i++){	
		
		//filter out numbers and gammar symbols.  If between 65 and 90 then needs to be encrypted
		if(text[i].charCodeAt(0) > 64 &&  text[i].charCodeAt(0) < 91){ 
			
			//[SPECIAL CASE FOR Z] If letter is "Z" then it needs to map to "Q" which has ascii code 81 (81-65 = 16)
			if(text[i].charCodeAt(0) == 90){
				
				//the spot for Q
				newText = newText += randomLetters[16]
			}
			else{
				//get spot in alphabet array
				let temp = text[i].charCodeAt(0) - 65; 
				//get corresponding letter from randomLetters array
				newText = newText += randomLetters[temp];
			}
			
		}
		else {
			// number or grammer symbol so just add it to the newText
			newText = newText += text[i];
		}
	}
	//output new encrypted text
	result.innerText = newText;
  	
	
}
