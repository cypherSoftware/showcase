
/* 
* JavaScript Document
* Name: Aaron Posey
* NetId: acposey
* For: Csc337 web programming class
* Instructor: Benjamin Dickens
* PA7 (Translation Project v2)
*
* This JS file runs a static server and also creates and API for being able to translate from English to German, English to Spanish, German to Spanish and there
* counter parts.  After the domain is typed in the URL bar, the user must type /tranlate followed by the conversion ex: /e2g followed by the words to 
* translate where each space is denoted by a "+" sign. A full example may be:  localhost:5000/translate/e2g/hello+world
*
* The server will then return the translated phrase.  For the type of conversion the user should use the following: e2g = english to spanish 
* s2g = spanish to german, etc.  There are 6 to work with: /e2g, /e2s, /s2e, /s2g, /g2e, /g2s.
*
* If the user uses the gui interface that is at index.html then the ajax request will send a get request with the proper url format and the 
* response will be placed in the gui interface instead.
*/



//Globals
const express = require('express')
const fs = require('fs');
const htmlTrans = require('fs');
const hostname = '127.0.0.1';
const port = 5000;
const app = express()


translatedWords = "";

e2g = {};  //dictionary 1
g2e = {};  //dictionary 2

e2s = {};  //dictionary 3
s2e = {};  //dictionary 4
//end Globals




/**************************************************************************Note*********************************************************************************
*
* This section of code runs first and loads dictionaries in before server is ran.
* For the s2g = {} and g2s = {}, they  are calculated by looking up the german or spanish and getting the english word then looking that word up
* in the corresponding dictionary.
*
***************************************************************************Note********************************************************************************/

//load dictionaries #1 and #2
readLines('./e2g.txt', 1);


//load dictionaries #3 and #4
readLines('./e2s.txt', 3);

//end load dictionary code






//declare public_html folder to serve static files
app.use(express.static('public_html'))

//if get request has three parameters and first parameter is '/translate' then run translate method on server and return results 
app.get('/:translate/:dictionaryName/:text', (req, res) => {

  var translate = req.params.translate;
  var dictionaryName = req.params.dictionaryName;
  var text = req.params.text;

	console.log(translate);
	console.log(dictionaryName);
	console.log(text);
	
	if(translate === 'translate'){

	//call translate()
		translateWords(dictionaryName, text);
		
	}
	
	res.send(translatedWords)
  });




//Functions()

/*Purpose: This function reads in the lines from the file passed in and parses the line then it adds the proper words 
*          to the proper dictionary 
* Parameters: accepts the file (string) and the dictionary number to identify which dictionary to inerts the words in.  
* Returns: Nothing
* Side effects: Changes the global variables e2g, g2e, e2s, and s2e.
*/
 async function readLines(fileName, dictionaryNum){
	
	var arr = [];	//array for parsing lines
	var input = fs.createReadStream(fileName);

	var rl = require('readline').createInterface({
	input: input,
	crlfDelay: Infinity
	//terminal: false
	
		})
	
	//this if statment is walking through the e2g.txt          ****English to German****
	if(dictionaryNum == 1){
		
		//grab one line at a time from text and add to dictionaries
		await rl.on('line', function(line) {
				
				//split current line into array of tokens 
				arr = line.split("\t").join(",").split("(").join(",").split("[").join(",").split(/[0-9]/).join(",").toLowerCase().split(",");
				
				//trim the words before placeing in dictionary
				for(i=0; i<arr.length; i++){
					arr[i] = arr[i].trim();
				}
				//add values to e2g dictionary
				//places first value in array which should be the english word into the e2g dictionary and assigns it the second value wich should
				// be the german translation.  Ignore'#' commented lines
				if(arr[0] != '#'){	
				
					e2g[arr[0]] = arr[1];
					g2e[arr[1]] = arr[0];

					
					
				}
		
			});		
	}
	 //this is walking through the e2s.txt                    ****English to Spanish****
	else{
		
		//grab one line at a time from text and add to dictionaries
		await rl.on('line', function(line) {
			
	
				//split current line into array of tokens 
				arr = line.split("\t").join(",").split("(").join(",").split("[").join(",").split(/[0-9]/).join(",").split(",");	
			
				//trim words before placing in dictionary
				for(i=0; i<arr.length; i++){
					arr[i] = arr[i].trim();
				}
				//add values to e2s dictionary
				//places first value in array which should be the english word into the e2s dictionary and assigns it the second value wich should
				// be the spanish translation 
				if(arr[0] != '#'){
					e2s[arr[0]] = arr[1];
					s2e[arr[1]] = arr[0];
				}
			
			});	
		
		
	}
}//end readLines()




/*Purpose: This function translates the words entered into the url using the designated dictionary.  
* Parameters: an array containing the parsed url with the dictionary to use and the words to translate 
* Returns: Nothing
* Side effects: Changes the global variable translatedString and ships it to the user.
*/	
function translateWords(dictionaryToUse, text){
	
	
	let wordsToTrans = [];
	let wordToLookUp = "";

	
	
	//put words to translate into wordsToTrans array by parsing string from array[] passed in.
	
	
	wordsToTrans = text.split("+");
	console.log("Will be translating: " + wordsToTrans);
	
	
	//use e2g dictionary 
	if(dictionaryToUse == 'e2g'){
		
		//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in e2g dictionary and translate it
			if(wordToLookUp in e2g){
				wordToLookUp = e2g[wordToLookUp];
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			//build string to return to user
			
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
		
	}
	//use g2e dictionary
	else if (dictionaryToUse == 'g2e'){
		
			//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in dictionary and translate it
			if(wordToLookUp in g2e){
				wordToLookUp = g2e[wordToLookUp];
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			//build string to return to user
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
		
	}
	//use e2s dictionary
	else if (dictionaryToUse == 'e2s'){
		
			//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in e2s dictionary and translate it
			if(wordToLookUp in e2s){
				wordToLookUp = e2s[wordToLookUp];
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			//add accent marks where needed
			
			wordToLookUp = wordToLookUp.replace(/a\//g,"á");
			wordToLookUp = wordToLookUp.replace(/e\//g,"é");
			wordToLookUp = wordToLookUp.replace(/i\//g,"í");
			wordToLookUp = wordToLookUp.replace(/o\//g,"ó");
			wordToLookUp = wordToLookUp.replace(/u\//g,"ú");
			wordToLookUp = wordToLookUp.replace(/u\./g,"ü");
			wordToLookUp = wordToLookUp.replace(/n~/g,"ñ" );
			
			
			
			//build string to return to user
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
		
	}
	//use s2e dictionary
	else if (dictionaryToUse == 's2e'){
		
			//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in s2e dictionary and translate it
			if(wordToLookUp in s2e){
				wordToLookUp = s2e[wordToLookUp];
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			//remove accent marks where needed and add appropriate symbol that's stored in dictionary
			
			wordToLookUp = wordToLookUp.replace(/á/g,"a/");
			wordToLookUp = wordToLookUp.replace(/é/g,"e/");
			wordToLookUp = wordToLookUp.replace(/í/g,"i/");
			wordToLookUp = wordToLookUp.replace(/ó/g,"o/");
			wordToLookUp = wordToLookUp.replace(/ú/g,"u/");
			wordToLookUp = wordToLookUp.replace(/ü/g,"u.");
			wordToLookUp = wordToLookUp.replace(/ñ/g,"n~");
			
			
			
			//build string to return to user
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
		
	}
	//use s2e and e2g dictionaries look up spanish word first then use it to look up german word
	else if (dictionaryToUse == 's2g'){
		
		//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in s2e dictionary and translate it
			if(wordToLookUp in s2e){
				wordToLookUp = s2e[wordToLookUp];
				
				//take english word and translate it into german
				if(wordToLookUp in e2g){
					wordToLookUp = e2g[wordToLookUp];
				}
					//translates from spanish to english but not english to german throw error
				else{
					wordToLookUp = "?"
				}
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			
			//build string to return to user
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
		
	}
	//use g2e and e2s dictionaries look up german word first then use it to look up spanish word
	else if (dictionaryToUse == 'g2s'){
		
			//reset string to null
		translatedWords = "";
		
		//walk through words to translate array and look up each word
		for(i=0; i < wordsToTrans.length; i++){
			
			//pull word out of array of words to translate it and assign to wordToLook up to use on dictionary
			wordToLookUp = wordsToTrans[i];
			
			//look up word in g2e dictionary and translate it
			if(wordToLookUp in g2e){
				
				wordToLookUp = g2e[wordToLookUp];
				
				//take english word and translate it into german
				if(wordToLookUp in e2s){
					
					wordToLookUp = e2s[wordToLookUp];
					
				}
					//translates from spanish to english but not english to german throw error
				else{
					wordToLookUp = "?"
				}
			}
			//current word not in dictionary return ???'s
			else {
				wordToLookUp = "?"
			}
			
			
			//add accent marks where needed for spanish
			
			wordToLookUp = wordToLookUp.replace(/a\//g,"á");
			wordToLookUp = wordToLookUp.replace(/e\//g,"é");
			wordToLookUp = wordToLookUp.replace(/i\//g,"í");
			wordToLookUp = wordToLookUp.replace(/o\//g,"ó");
			wordToLookUp = wordToLookUp.replace(/u\//g,"ú");
			wordToLookUp = wordToLookUp.replace(/u\./g,"ü");
			wordToLookUp = wordToLookUp.replace(/n~/g,"ñ" );
			
			
			
			//build string to return to user
			translatedWords = translatedWords + wordToLookUp + " ";
			
		}
		
	}
	//if dictionary is e2e, s2s, or g2g then just return text no translation neccessary
	else if (dictionaryToUse == 'e2e' || dictionaryToUse == 'g2g' || dictionaryToUse == 's2s'){
		
		text = text.replace(/\+/g," ");
		translatedWords = text;
	}
	//no legal dictionary was designated return an error
	else{
		
		translatedWords = "sorry please pick a legal dictionary to use using: e2g, e2s, s2e, g2e , s2g, or g2s";
	}
	
}//end translate()
	



/************************************************************************************************************************************ 
*This section starts the server and listens for requests from user.  Upon request the appropriate translation code will run otherwise
*  the user simply gets the word "ok" returned.
*************************************************************************************************************************************/


app.listen(port, () => 
  console.log(`App listening at http://localhost:${port}`))

