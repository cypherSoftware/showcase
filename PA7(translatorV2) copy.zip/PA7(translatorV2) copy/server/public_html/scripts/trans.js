/* 
*JavaScript Document
*Name: Aaron Posey
*NetId: acposey
*For: Csc337 web programming class
*Instructor: Benjamin Dickens
*PA7 (Translator v2)
*
*This JS file is allows the user to interact with the translation interface.  The user selects the from and to language then types text in the left hand side
*box.  The changing of text or pull down menu will fire a translate request via an ajax object.
*/



/*  Purpose: This function creates an xmlhttp request and grabs the values from the language selection menus and the text fields and creates a custom url
*   		 for the get request and then sends it to the server then puts the response in the other text field.  
*   Returns: Nothing
*   Side effects: changes the html code on the translated text box to reflect what the server sent back
*/
function makeTranslation() {
  var httpRequest = new XMLHttpRequest();
  if (!httpRequest) {
    alert('Error!');
    return false;
  }

  httpRequest.onreadystatechange = () => {
    if (httpRequest.readyState === XMLHttpRequest.DONE) {
      if (httpRequest.status === 200) {
        
	
		  console.log(httpRequest.responseText);
		  //get translated text box  element from html
		  let translatedTextBox = document.getElementById('tranText');
		  //place translated text from server into translated text box
		  translatedTextBox.value = httpRequest.responseText
		  
		  
      } else { alert('ERROR'); }
    }
  }

 
	
  //grab text to be translated from leftside textbox of html and assign it to textToTranslate variable
  let textToTranslate = document.getElementById('text2Tran').value;
  let fromLanguage = document.getElementById('fromLang').value;
  let toLanguage = document.getElementById('toLang').value;
	
  let dictionaryToUse = '';
	
	
	// use language selected in boxes to build string for which dictionary to use.  
	
	//first part of dictionary string
	if(fromLanguage == 'English'){
		dictionaryToUse = dictionaryToUse + 'e2';
	}
	else if (fromLanguage == 'Spanish'){
		dictionaryToUse = dictionaryToUse + 's2';
	}
	else{
		dictionaryToUse = dictionaryToUse + 'g2';
	}
		//second part of dictionary string
	if(toLanguage == 'English'){
		dictionaryToUse = dictionaryToUse + 'e/';
	}
	else if (toLanguage == 'Spanish'){
		dictionaryToUse = dictionaryToUse + 's/';
	}
	else{
		dictionaryToUse = dictionaryToUse + 'g/';
	}
	
	
	  //create string of text to translate with all spaces suplanted with + signs because thats what translate() expects on server side.
	textToTranslate = textToTranslate.replace(/\s/g,"+");
	console.log("The text for the url is going to be: " + textToTranslate);
	
	
	//build custom url for ajax request
	let url = 'http://localhost:5000/translate/' + dictionaryToUse + textToTranslate;
	
	
	// if statment stops the xml request from sending if the textToTranslate text box is null.  There's nothing to translate. 
	//(prevents clearing the text box by the user from firing a translation request thats supposed to trigger onChange)
	if(textToTranslate != ''){
		console.log("textToTranslate value b4 xml request is sent: " + textToTranslate);
  httpRequest.open('GET', url);
  httpRequest.send();
	}
	
}
