{-gcd.hs:  The gcd function accepts to integers and returns the greatest number that can
-divide both evenly.
-}


ourGcd :: Integer -> Integer -> Integer
-- Uses mod to recursively get gcd. If y is 0 then it returns x and if x is 0 then it will
-- run once get to 0 then return y.
-- program will recursively call ourGcd until a value of 0 is reached somewhere and
-- return the left over number which is the gcd.

ourGcd x y

  | y /= 0 = (ourGcd y (mod x y)) 
  | otherwise = x