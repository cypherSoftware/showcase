{-insertionsort.hs:  This program accepts a list of integers and returns an ordered list.
--it will call the insertInOrder function to place each int in a new list in proper order
-}


--this function accepts an ordered list and an int and it places that int in the list 
--in its proper order

insertInOrder :: Int -> [Int] -> [Int]

 --if list is empty just add int to list
insertInOrder n [] = [n]

--if list has more than one element call insertInOrder recursively to find proper position
--then reconstruct the list
insertInOrder n (x:xs)
   | n < x = n:(x:xs)
   | otherwise =  x:insertInOrder n xs






--this function recursively calls insertInOrder on the head of a list until whole list is sorted
insertionSort :: [Int] -> [Int]

insertionSort [] = []
insertionSort (x:xs) = insertInOrder x (insertionSort xs)