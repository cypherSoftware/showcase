{-vowels.hs:  The vowels program uses a main method to call for user input.  The input is
-- then combed through to remove all the vowels and a histogram is displayed to show how
-- many of each vowel there was in the user input.
-}


import Data.Char (toLower)









-- This function accepts a string and returns a list of strings that contains only the vowels

vowelListList :: String -> [String]

vowelListList ip = [(filter (=='a') ip)] ++ [(filter (=='e') ip)] ++ [(filter (=='i') ip)] ++ [(filter (=='o') ip)] ++ [(filter (=='u') ip)]









-- this function forces all the input into lowercase

lowerString :: String -> String

lowerString s = map toLower s 







--this function accepts a list of strings and then uses the zipWith function to add a (\n vowel:) prefix to each
--string of vowels in the list and then the list of strings is concatenated into one string to allow the
--histogram to be printed when called with putStrLn

vowelHistogram :: [String] -> String

vowelHistogram strLst = concat (zipWith (++) ["a: ","\ne: ", "\ni: ", "\no: ", "\nu: "] (strReplace (strLst)))







--this function replaces a list strings containing all vowels with a list of stars that count how many vowels
-- were in each string.
 
strReplace :: [String] -> [String]

strReplace a = map (makeStars) a





--this function takes a string of vowels and replaces it with stars, one star for each vowel.
makeStars :: String -> String

makeStars s = concat (take (length s) (repeat "*"))





--this function gets input from the user and and displays a histogram of all the vowels contained in the input
main :: IO ()

main = do

   --get input
   input <- readFile "vowels.txt"

   --print out histogram
   putStrLn (vowelHistogram((vowelListList (lowerString input))))

